public class MainAgent {
    public static void main(String[] args) {
        StartAgent.main(args);
    }
}