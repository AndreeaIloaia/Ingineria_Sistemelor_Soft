package validator;

import domain.Produs;

public class ValidatorProdus  implements Validator<Produs> {
    @Override
    public void validate(Produs entity) {

    }
}
