package validator;

import domain.Admin;

public class ValidatorAdmin  implements Validator<Admin> {
    @Override
    public void validate(Admin admin) {

    }
}
