import domain.Agent;
import domain.Comanda;
import domain.Detalii;
import domain.Produs;
import jdbc.RepoAgent;
import jdbc.RepoComanda;
import jdbc.RepoDetalii;
import jdbc.RepoProdus;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Ma {
    public static void main(String[] args) {
        //RepoAdmin test = new RepoAdmin();
        //Admin c = test.cauta("Andreea", "da");
        /*RepoProdus prod = new RepoProdus();

        prod.delete(10);
        List<Produs> p = new ArrayList<>();
        Iterable<Produs> list = prod.getAll();
        for(Produs p1 : list){
            p.add(p1);
        }
        System.out.println(p);
        RepoAgent repo = new RepoAgent();
        Agent c = repo.cauta("Andreea", "da");
        Agent c2 = repo.cauta("Danut", "trei");
        System.out.println(c);
        System.out.println(c2);



        RepoComanda repoComanda = new RepoComanda();
        LocalDate today = LocalDate.parse("2019-03-29");
        System.out.println(today);
        repoComanda.update(2, new Comanda(0,"", 200, "2019-03-29"));
        //repoComanda.save(new Comanda(2, "Ana", 100, LocalDate.parse("2020-05-24")));
        for(Comanda c : repoComanda.getAll()){
            System.out.println(c);
        }


        RepoDetalii repoDetalii = new RepoDetalii();
        //repoDetalii.save(new Detalii(1, 2));
        for(int i: repoDetalii.cauta(1)){
            System.out.println(i);
        }*/


    }
}